//
//  Scene6.swift
//  PlaygroundBook
//
//  Created by Djenifer Renata Pereira on 12/04/21.
//

import Foundation
import SpriteKit

public class Scene6: PreScene {
    
    override public func didMove(to view: SKView) {
        self.backgroundColor = .white
        setup()
    }
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }

    func setup() {
        let text = setupText(texts: [
            ("A lenda conta que Naipi se tornou uma rocha no meio das Cataratas", 1),
            ("e Tarobá se tornou uma palmeira.", 5),
            ("", 0),
            ("Dessa maneira, eles estão condenados a se ver sem poder estarem juntos de novo.", 7.5)
        ])
        text.position = CGPoint(x: self.size.width / 2, y: self.size.height - 200)

        self.addChild(text)

        self.run(.sequence([
            .wait(forDuration: 3),
            .run {
                let animation = self.setupAnimation()
                let whiteRect = SKShapeNode(rect: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
                whiteRect.fillColor = .white
                whiteRect.zPosition = self.UI_ZPOSITION - 1

                let fadeOut = SKAction.fadeOut(withDuration: 1)
                fadeOut.timingMode = .easeIn
                whiteRect.run(fadeOut)

                self.addChild(whiteRect)
                self.addChild(animation)
            }
        ]))
    }

    func setupAnimation() -> SKNode {
        let background = SKNode()
        background.position = CGPoint(x: -150, y: 100)
        
        let falls = self.setupRiverBackground()
        falls.zRotation = toRadians(-5)
        falls.position = CGPoint(x: self.size.width * 0.35, y: 250)
        
        let fallsLines = self.setupFallsLines(hideMiddleLine: true)
        fallsLines.position = CGPoint(x: 2100, y: -1000)
        
        falls.addChild(fallsLines)
        background.addChild(falls)
        
        let rock = setupRock()
        rock.position = CGPoint(x: self.size.width - 150, y: 50)
        
        background.addChild(rock)
        
        let earthAndPalm = setupEarthAndPalm()
        earthAndPalm.position = CGPoint(x: -300, y: 50)
        background.addChild(earthAndPalm)
        
        background.run(.sequence([
            .wait(forDuration: 2),
            .move(to: CGPoint(x: 600, y: 100), duration: 1.5),
            .wait(forDuration: 1.5),
            .group([
                .move(to: CGPoint(x: 400, y: 100), duration: 1.5),
                .scale(to: 0.7, duration: 1.5)
            ])
        ]))
        
        let take6 = SKNode()

        take6.addChild(background)

        let infoBox = setupInfoBox()
        infoBox.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.4)
        infoBox.alpha = 0

        take6.addChild(infoBox)

        let handButton = setupHandButton(infoNode: infoBox, setupNextPage: false)
        handButton.position = CGPoint(x: self.size.width * 0.5, y: 200)

        take6.run(.sequence([
            .wait(forDuration: 10),
            .run {
                take6.addChild(handButton)
            }
        ]))

        if let waterfallSound = self.setupMusic(resource: "scene-6", withExtension: "mp3") {
            waterfallSound.run(.sequence([
                .changeVolume(to: 0, duration: 0),
                .changeVolume(to: 0.04, duration: 1.5)
            ]))
            self.sounds.append(waterfallSound)
            self.addChild(waterfallSound)
        }

        return take6
    }

    func setupInfoBox() -> SKNode {
        let node = SKNode()

        let balloon = SKSpriteNode(imageNamed: "b-5")
        balloon.zPosition = UI_ZPOSITION + 3
        balloon.setScale(0.5)

        let infoText = setupParagraph(
            text: "Essa lenda tem outras versões,\n mas a essência é\n Naipi e Tarobá fugindo\n e Mboi criando as Cataratas,\n como foi contado aqui.",
            font: self.infoFont, fontSize: 30
        )
        infoText.zPosition = UI_ZPOSITION + 4
        infoText.position = CGPoint(x: 0, y: -25)

        node.addChild(infoText)
        node.addChild(balloon)

        return node
    }
    
    func setupRock() -> SKNode {
        let node = SKNode()
        
        let rock = SKSpriteNode(imageNamed: "rock")
        rock.zPosition = CHARACTER_ZPOSITION
        
        node.addChild(rock)
        node.setScale(0.5)
        
        return node
    }
    
    func setupEarthAndPalm() -> SKNode {
        let node = SKNode()
        
        let earth = SKSpriteNode(imageNamed: "earth-1-rescale")
        earth.yScale = earth.yScale * -1
        earth.position = CGPoint(x: -200, y: -400)
        earth.zRotation = toRadians(-7)
        earth.zPosition = CHARACTER_ZPOSITION + 1
        
        let palm = SKSpriteNode(imageNamed: "palm")
        palm.zPosition = CHARACTER_ZPOSITION + 2
        palm.position = CGPoint(x: 100, y: 500)
        
        node.addChild(earth)
        node.addChild(palm)
        
        node.setScale(0.5)
        
        return node
    }
}
